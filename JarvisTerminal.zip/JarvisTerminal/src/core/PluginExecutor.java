package src.core;

import src.plugins.*;

public class PluginExecutor {
    public void execute(String pluginName, String input) {
        JarvisPlugin plugin;

        switch (pluginName) {
            case "OpenChromePlugin":
                plugin = new OpenChromePlugin();
                break;
            case "DateTimePlugin":
                plugin = new DateTimePlugin();
                break;
            case "JokePlugin":
                plugin = new JokePlugin();
                break;
            case "ShutdownPlugin":
                plugin = new ShutdownPlugin();
                break;
            default:
                System.out.println("❌ No matching plugin found for: " + pluginName);
                return;
        }

        plugin.execute(input);
    }
}
