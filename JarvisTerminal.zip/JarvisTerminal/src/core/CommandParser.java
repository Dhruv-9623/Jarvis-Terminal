package src.core;

import java.util.HashMap;
import java.util.Map;

public class CommandParser {
    private final Map<String, String> triggerMap = new HashMap<>();

    public CommandParser() {
        triggerMap.put("open chrome", "OpenChromePlugin");
        triggerMap.put("what's the time", "DateTimePlugin");
        triggerMap.put("tell me a joke", "JokePlugin");
        triggerMap.put("joke", "JokePlugin");
        triggerMap.put("shutdown", "ShutdownPlugin");
        triggerMap.put("shut down", "ShutdownPlugin");
    }

    public String parse(String input) {
        for (String trigger : triggerMap.keySet()) {
            if (input.contains(trigger)) {
                return triggerMap.get(trigger);
            }
        }
        return "UnknownPlugin";
    }
}
