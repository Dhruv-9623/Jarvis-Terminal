package src.plugins;

import java.io.IOException;

public class OpenChromePlugin implements JarvisPlugin {
    @Override
    public void execute(String command) {
        try {
            Runtime.getRuntime().exec("cmd /c start chrome");
            System.out.println("✅ Chrome launched successfully.");
        } catch (IOException e) {
            System.out.println("❌ Failed to launch Chrome.");
            e.printStackTrace();
        }
    }
}
