package src.plugins;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimePlugin implements JarvisPlugin {
    @Override
    public void execute(String command) {
        LocalDateTime now = LocalDateTime.now();
        String time = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        System.out.println("🕒 Current time is: " + time);
    }
}
