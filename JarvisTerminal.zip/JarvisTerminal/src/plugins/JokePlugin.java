package src.plugins;

import java.util.Random;

public class JokePlugin implements JarvisPlugin {
    private final String[] jokes = {
            "Why do programmers hate nature? It has too many bugs.",
            "Real programmers count from 0.",
            "Why did the Java developer wear glasses? Because he couldn't C#."
    };

    @Override
    public void execute(String command) {
        Random rand = new Random();
        String joke = jokes[rand.nextInt(jokes.length)];
        System.out.println("😂 " + joke);
    }
}
    }
}
