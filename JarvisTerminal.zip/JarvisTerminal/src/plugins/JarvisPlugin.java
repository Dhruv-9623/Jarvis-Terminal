package src.plugins;

public interface JarvisPlugin {
    void execute(String command);
}
