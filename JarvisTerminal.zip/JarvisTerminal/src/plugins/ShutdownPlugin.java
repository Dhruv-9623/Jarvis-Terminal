package src.plugins;

public class ShutdownPlugin implements JarvisPlugin {
    @Override
    public void execute(String command) {
        System.out.println("⚠️ Simulating system shutdown...");
        System.out.println("💤 Goodbye...");
        // WARNING: For real use, uncomment:
        // Runtime.getRuntime().exec("shutdown -s -t 0");
    }
}
    }
}
