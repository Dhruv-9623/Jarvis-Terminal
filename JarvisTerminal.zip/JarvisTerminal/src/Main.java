package src;

import src.core.CommandParser;
import src.core.PluginExecutor;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("🧠 JarvisTerminal 1.0 — Initialized");
        System.out.println("-----------------------------------");
        System.out.println("🎙️  Speak your command (type for now):");

        Scanner scanner = new Scanner(System.in);
        CommandParser parser = new CommandParser();
        PluginExecutor executor = new PluginExecutor();

        while (true) {
            System.out.print("🗣️  You: ");
            String input = scanner.nextLine().toLowerCase().trim();

            if (input.isBlank())
                continue;
            if (input.contains("exit"))
                break;

            String pluginName = parser.parse(input);
            executor.execute(pluginName, input);
        }

        System.out.println("👋 Exiting JarvisTerminal. Goodbye.");
    }
}
